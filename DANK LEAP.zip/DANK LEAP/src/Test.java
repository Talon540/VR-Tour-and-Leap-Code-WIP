import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import com.leapmotion.leap.*;
public class Test 
{
	public static void main(String[] args)
	{
		SampleListener listen = new SampleListener();
		Controller controller = new Controller();
		controller.addListener(listen);
		System.out.println("Press enter to quit");
		try 
		{
			System.in.read();
		}catch (IOException e) {
			e.printStackTrace();
		}
		controller.removeListener(listen);
	}
}