import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import com.leapmotion.leap.Controller;
import com.leapmotion.leap.Frame;
import com.leapmotion.leap.Hand;
import com.leapmotion.leap.Listener;
import com.leapmotion.leap.Matrix;
import com.leapmotion.leap.Tool;
import com.leapmotion.leap.Vector;
public class SampleListener extends Listener
{
	private double pitch = 0.0;
	public void onConnect(Controller controller)
	{
		controller.setPolicy(Controller.PolicyFlag.POLICY_BACKGROUND_FRAMES);
		controller.setPolicy(Controller.PolicyFlag.POLICY_IMAGES);
		controller.setPolicy(Controller.PolicyFlag.POLICY_OPTIMIZE_HMD);
		System.out.println("YOU HAVE CONNECTED");
	}
	public void onFrame(Controller controller)
	{
		Frame frame = controller.frame();
	 for(Hand hand : frame.hands()) 
	 {
        
         if(hand.palmPosition().getX() < -100)
         {
        	 try {
 				Robot robot = new Robot();
 				//robot.delay(100);
 				robot.keyPress(KeyEvent.VK_A);
 				robot.keyRelease(KeyEvent.VK_A);
 			} catch (AWTException e) {
 				e.printStackTrace();
 			}
         }
         else if(hand.palmPosition().getX() > 100)
         {
        	 try {
 				Robot robot = new Robot();
 				//robot.delay(100);
 				robot.keyPress(KeyEvent.VK_D);
 				robot.keyRelease(KeyEvent.VK_D);
 			} catch (AWTException e) {
 				e.printStackTrace();
 			}
         }	 
        if(hand.palmPosition().getZ() < -100)
        {
        	try {
				Robot robot = new Robot();
				//robot.delay(100);
				robot.keyPress(KeyEvent.VK_W);
				robot.keyRelease(KeyEvent.VK_W);
			} catch (AWTException e) {
				e.printStackTrace();
			}
        }
        else if(hand.palmPosition().getZ() > 100)
        {
        	try {
				Robot robot = new Robot();
				//robot.delay(100);
				robot.keyPress(KeyEvent.VK_S);
				robot.keyRelease(KeyEvent.VK_S);
			} catch (AWTException e) {
				e.printStackTrace();
			}
        }
     }
    
  }
}
